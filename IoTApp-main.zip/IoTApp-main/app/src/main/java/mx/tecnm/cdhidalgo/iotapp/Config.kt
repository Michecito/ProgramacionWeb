package mx.tecnm.cdhidalgo.iotapp

class Config {
    companion object {
        //url de la API REST
        val URL: String = "https://iotrest.itsch.kyared.com/"
    }
}